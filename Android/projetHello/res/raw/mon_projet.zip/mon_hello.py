import android

droid = android.Android()
droid.ttsSpeak('Qui êtes-vous ?')
name = str(droid.recognizeSpeech().result)
droid.ttsSpeak('Bonjour ' + name)
